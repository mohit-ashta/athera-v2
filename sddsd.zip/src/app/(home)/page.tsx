import { Homepage } from "@/features/home-page";

export default function page() {
    return <Homepage />
}