import { SignInPage } from "@/features/auth/sign-in";
import React from "react";

const page = () => <SignInPage />;

export default page;
