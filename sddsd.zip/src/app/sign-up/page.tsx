import { SignUpPage } from "@/features/auth/sign-up";
import React from "react";

const page = () => <SignUpPage />;
export default page;
