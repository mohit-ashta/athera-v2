import { TherapyListPage } from '@/features/home-page/therapy-list'
import React from 'react'

const page = () => <TherapyListPage/>

export default page