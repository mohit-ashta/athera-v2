import { StoryWallPage } from '@/features/home-page/story-wall'
import React from 'react'

const page = () => <StoryWallPage/>

export default page