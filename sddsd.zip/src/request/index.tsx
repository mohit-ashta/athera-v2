import { Fetcher } from "./api-service";

export const request = new Fetcher();

