export const commentsData = [
  {
    author: "maverick",
    date: "Jan 21, 2024",
    text: "Reaching out for help at your lowest point in nearly impossible to do. Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "maverick",
    date: "Jan 21, 2024",
    text: "Reaching out for help at your lowest point in nearly impossible to do. Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "maverick",
    date: "Jan 21, 2024",
    text: "Reaching out for help at your lowest point in nearly impossible to do. Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "maverick",
    date: "Jan 21, 2024",
    text: "Reaching out for help at your lowest point in nearly impossible to do. Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "maverick",
    date: "Jan 21, 2024",
    text: "Reaching out for help at your lowest point in nearly impossible to do. Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
];

export const Stories = [
  {
    author: "unknown",
    date: "Jan 21, 2024",
    text: " exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "john",
    date: "Jan 21, 2024",
    text: "Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "unknown",
    date: "Jan 21, 2024",
    text: " exactly who could help me get out of one of the darkest places I’ve been in.",
  },
  {
    author: "john",
    date: "Jan 21, 2024",
    text: "Thank you for recognizing exactly who could help me get out of one of the darkest places I’ve been in.",
  },
];
