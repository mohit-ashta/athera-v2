export const cardImage =[
    {
      src: "/assets/save.webp",
      text: "Save your filtered preferences",
    },
    {
      src: "/assets/bookmark.webp",
      text: "Bookmark your favorite therapists",
    },
    {
      src: "/assets/mail.webp",
      text: "Send consultation requests to multiple therapists from your favorite list",
    },
  ]