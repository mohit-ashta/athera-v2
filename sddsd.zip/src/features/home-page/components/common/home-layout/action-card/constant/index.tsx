export  const cards = [
    {
      title: "Call Someone",
      description: "Currently 10-12 calls a week on ALPA PA",
      linkText: "Learn more",
    },
    {
      title: "Private Chat",
      description: "Anonymous chat with an AI bot to help direct",
      linkText: "Learn more",
    },
    {
      title: "On Demand Resources",
      description: "Completely confidential & saves valuable time",
      linkText: "Learn more",
    },
  ];